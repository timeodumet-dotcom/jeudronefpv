# AeroLab RC (version avec IA) : mode d'emploi

Cette version est identique au jeu de base, avec **l'IA en plus**. Il y a toujours **un seul fichier : `index.html`**.

## Comment ça marche
Sur un site public, le jeu ne peut pas utiliser l'IA de Claude comme dans la démo. Ici, **chaque joueur utilise sa propre clé API Anthropic** :
- Au premier usage de l'IA (ou via le bouton « Clé API » du menu d'accueil), le jeu demande une clé.
- La clé reste **dans le navigateur du joueur** (jusqu'à la fermeture de l'onglet, ou durablement s'il coche « Me souvenir »).
- Elle n'est envoyée **qu'à api.anthropic.com**. Ton site ne la voit jamais et ne la stocke nulle part.
- Les générations consomment des crédits du compte API **du joueur**, pas les tiens.
- Sans clé, tout le reste du jeu marche normalement (modèles prédéfinis, scénarios rapides).

## Pour le mettre en ligne (GitHub Pages)
1. Sur la page de ton dépôt GitHub, clique sur `index.html`, puis sur le crayon (Edit) ou sur « ... » puis supprime l'ancien fichier, **ou** envoie simplement le nouveau `index.html` avec « Add file » puis « Upload files » : il remplace l'ancien s'il porte le même nom.
2. Clique sur « Commit changes ».
3. Attends 1 à 2 minutes, puis recharge ton site avec Ctrl + F5.

## Obtenir une clé API (pour toi ou tes joueurs)
1. Va sur https://console.anthropic.com et crée un compte.
2. Ajoute des crédits (la facturation de l'API est **séparée** d'un abonnement Claude).
3. Crée une clé API (« API keys »), idéalement une clé **dédiée au jeu** avec une limite de dépense.
4. Colle-la dans la fenêtre du jeu (elle commence par `sk-ant-`).

## Sécurité : à lire
- **Ne mets JAMAIS ta clé dans le fichier ni dans le dépôt GitHub.** Un dépôt public est parcouru par des robots : une clé publiée est volée en quelques minutes et peut te coûter cher.
- Dis à tes joueurs de ne saisir leur clé que sur leur propre appareil, et de créer une clé avec une limite de dépense.
- Le choix du modèle se fait dans le fichier, constante `AI_MODEL` (cherche-la dans `index.html`). Si Anthropic renomme ou retire ce modèle, remplace le nom par un modèle actuel.

## Si tu veux que l'IA marche pour tout le monde sans clé
Il faut un petit **serveur intermédiaire** (par exemple une fonction Cloudflare Workers ou Netlify) qui garde TA clé secrète et limite l'usage de chaque joueur. Ça fonctionne, mais **c'est toi qui paies** les appels et il faut bien protéger l'accès (limites, anti-abus). Demande-moi si tu veux que je te prépare cette version.

## Le reste
Les autres infos (hébergement, appareils, licence three.js, nom du jeu) sont dans le `LISEZMOI.md` de la version de base.

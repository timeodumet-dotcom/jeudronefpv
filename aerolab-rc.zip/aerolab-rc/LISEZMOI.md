# AeroLab RC : mode d'emploi pour mettre le jeu en ligne

Ce dossier contient **tout le jeu dans un seul fichier : `index.html`**.
Il n'a besoin de rien d'autre : pas de serveur, pas de base de données, pas d'Internet pour fonctionner
(le moteur 3D three.js est déjà inclus dans le fichier).

## 1. Tester chez toi (30 secondes)
Double-clique sur `index.html` : le jeu s'ouvre dans ton navigateur (Chrome, Edge, Firefox ou Safari récents).

## 2. Le mettre en ligne gratuitement (choisis UNE méthode)

### Méthode A : Netlify Drop (la plus simple, sans compte pour essayer)
1. Va sur https://app.netlify.com/drop
2. Glisse-dépose le **dossier `aerolab-rc`** (celui qui contient `index.html`) sur la page.
3. Netlify te donne tout de suite une adresse du type `https://nom-au-hasard.netlify.app`.
4. Pour garder le site et changer son nom : crée un compte gratuit, "réclame" le site, puis modifie le nom dans les réglages du site.

### Méthode B : GitHub Pages
1. Crée un compte sur https://github.com
2. Crée un nouveau dépôt **public** (par exemple `aerolab-rc`).
3. Clique sur "Add file", puis "Upload files", envoie `index.html`, puis valide ("Commit").
4. Va dans "Settings", puis "Pages". Choisis "Deploy from a branch", la branche `main` et le dossier `/ (root)`. Enregistre.
5. Après 1 à 2 minutes, le jeu est en ligne à l'adresse `https://TON-PSEUDO.github.io/aerolab-rc/`.

### Méthode C : Cloudflare Pages
1. Crée un compte gratuit sur https://dash.cloudflare.com
2. Va dans "Workers & Pages", "Create", "Pages", puis choisis l'envoi direct de fichiers ("Upload assets").
3. Envoie le dossier `aerolab-rc`, donne un nom au projet et valide.

(Les menus de ces sites changent de temps en temps : si un nom de bouton est différent, cherche l'équivalent.)

## 3. Mettre à jour le jeu plus tard
Remplace simplement `index.html` par la nouvelle version, puis renvoie-le :
- Netlify : refais un glisser-déposer sur la page "Deploys" de ton site.
- GitHub : "Add file", "Upload files", puis écrase le fichier.

## 4. À savoir
- **Appareils** : clavier + souris, manette Xbox, ou téléphone/tablette (sticks tactiles, mets l'écran en paysage). Un ordinateur récent donne la meilleure fluidité ; le jeu baisse tout seul la qualité s'il a du mal.
- **Sauvegarde** : seul le niveau débloqué du mode urgence est gardé, dans le navigateur de chaque joueur (aucun compte, aucune donnée envoyée).
- **IA** : les fonctions d'IA ne sont pas dans cette version publique (elles ne marchent que dans l'environnement Claude). Les modèles (drone, 3 avions, 2 hélicos) et les scénarios du mode urgence fonctionnent sans IA.
- **Nom** : "AeroLab RC" est un nom provisoire. Vérifie qu'il est libre avant de le promouvoir, ou remplace-le dans `index.html` (cherche `AEROLAB RC` et `AeroLab RC`).
- **Licence** : le moteur 3D three.js est sous licence MIT. Son texte de licence est conservé dans le fichier : ne le supprime pas.
- **Aucune image ni aucun fichier de jeu tiers** n'est utilisé : les décors et les modèles sont générés par le code.
